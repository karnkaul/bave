#include "config.h"

#ifdef ALSOFT_EAX

#include <cassert>
#include "AL/efx.h"
#include "effects.h"

#endif // ALSOFT_EAX
