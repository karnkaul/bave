If you are not redirected automatically, follow the
`link to the fmt documentation <https://fmt.dev/latest/>`_.
